# Copyright 2020 -- Natalia Alvarado <contact@natalia.im>
# Intended license: BSD 2-clause
# https://opensource.org/licenses/BSD-2-Clause

# R-Basics online seminar
# Introduction to graphs in R - Part I

# R is rapidly becoming one of the most popular tools for graphs. 
# This is due to its flexibility and libraries. This walk-through is an
# introduction to how to make simple graphs and a couple of tips on
# styling, user-made tools and overall working with graphs.
# There are many ways to do things in R. In this code, I keep things
# as basic and separate as they can, however there are more efficient
# ways to get the same results. 
# New users: as you can see, you can write comments using the hash before 
# text


# What we will do with this code:
# 1. Basics: install and call packages, load dataframes and assignments
# 2. Make scatterplots: Base and ggplot2

# The next session:
# 3. Other types of graphs
# 4. Make things pretty: ggthemes, Rcolorbewer and patchwork



# 1. Basics

# Install packages we will work with if not installed before and load (Only the first time)

install.packages("ggplot2") # Nice library for creating easy graphs
install.packages("RColorBrewer") # For adding nice color palettes
install.packages("patchwork") # For putting images in one grid
install.packages("ggthenmes") # For making plots pretty without so much effort
install.packages("ggrepel") # For text labels
install.packages("countrycode")


# Load packages (different from Stata, you must install once, but load every time)
library(ggplot2)


# Objects, vectors, and variables
o1 <- "something"
o2 <- c("A", "list", "of", "things")
o3 <- c(1, 2, 3, 4)

sample_df <- data.frame(o2, o3)

# Load data: one can load several datasets in the same session in R. Data is almost
# always a matrix with rows and columns

df_from_path <- read.csv("C:/Users/xalvna/Desktop/qog_online_workshops/qog_bas_ts_jan20.csv")
# Tip for the future: Windows uses backslash! R uses slash

  # or
df_from_web <- read.csv("https://www.qogdata.pol.gu.se/data/qog_bas_ts_jan20.csv")

  # or
df <- read.csv("qog_bas_ts_jan20.csv") # Relative paths detour (Also possible in Stata, 
# makes collaborative research easier!)


# View your dataset
View(df)


# Check variables names in the dataframe
names(df)

# Because you can have multiple datasets at the same time, you must specify dataset and
# variable, you do that by writing df$variable, the dollar sign indicates you are trying
# to access the variable inside that dataset
df$cname

# Check the unique values of a variable
unique(df$cname)



# Graphs with basic R. Base R is powerful
plot(x = df$undp_hdi, y = df$wdi_gdpcapcon2010) # Simplest way to plot a scatterplot 


# Too many observations per year, focus on one year (subsetting information)
df1 <- subset(df, year == 2014)


plot(x = df1$undp_hdi, y = df1$wdi_gdpcapcon2010) # Better but needs to use a log scale!

plot(x = df1$undp_hdi, y = log10(df1$wdi_gdpcapcon2010))



# Adding titles and labels
plot(x = df1$undp_hdi, y = df1$wdi_gdpcapcon2010,
     main = "Development and GDP in 2014",
     xlab = "HDI",
     ylab = "GDP per capita (2010 USD)")



# Adding a regression line, we must tell the plot how to draw it, in this case with "lm" 
# we tell it it's a linear model
plot(x = df1$undp_hdi, y = df1$wdi_gdpcapcon2010,
     main = "Development and GDP in 2014",
     xlab = "HDI",
     ylab = "GDP per capita (2010 USD)",
     abline(lm(wdi_gdpcapcon2010 ~ undp_hdi, data = df1), col = "blue"))


# But we forgot the log! Better make a new variable out of it
df1$newgdp <- log10(df1$wdi_gdpcapcon2010)


# Run vs assign
log10(df$undp_hdi)
df1$newgdp <- log10(df1$wdi_gdpcapcon2010)



plot(x = df1$undp_hdi, y = df1$newgdp,
     main = "Development and GDP in 2014",
     xlab = "HDI",
     ylab = "GDP per capita (2010 USD)",
     abline(lm(newgdp ~ undp_hdi, data = df1), col = "blue"))



# How can I save my plot?
png("rplot.png", width = 350, height = 350)

plot(x = df1$undp_hdi, y = df1$newgdp,
     main = "Development and GDP in 2014",
     xlab = "HDI",
     ylab = "GDP per capita (2010 USD)",
     abline(lm(newgdp ~ undp_hdi, data = df1), col = "blue"))

dev.off() # Removes the plot



# ggplot2 AKA all the pretty graphs you have seen from R
p1 <- ggplot(data = df1, aes(x = undp_hdi, y = newgdp)) 
p1 # It created a blank graph!



# Ggplot needs specification of WHAT to plot
p1 <- ggplot(data = df1, aes(x = undp_hdi, y = newgdp)) +
  geom_point() # this is what makes the scatterplot
p1


# Add color and the difference between aesthetic parameters and others
p1 <- ggplot(data = df1, aes(x = undp_hdi, y = newgdp)) +
  geom_point(color = "red") +
  labs(title = "Development and GDP in 2014",
       x = "HDI",
       y = "GDP per capita (2010 USD)"
  )
p1


# How do I add a regression line? geom_smooth is the answer!
# It needs to know which method and the formula for the line
# Learn more about the methods here: https://ggplot2.tidyverse.org/reference/geom_smooth.html
# and here! https://stats.idre.ucla.edu/r/faq/how-can-i-explore-different-smooths-in-ggplot2/
p1 <- p1 + geom_smooth(method='lm', formula= y~x) 
p1


# Making it pretty without fuss
p1 <- p1 + theme_classic() # use theme() to see what is available or check
# https://ggplot2.tidyverse.org/reference/ggtheme.html
p1


# How do we save? Easier than in base
ggsave("graph_1.png", p1)

# End of first session


# Code by Natalia Alvarado Pachon